from flask import Flask, render_template

app = Flask(__name__)

@app.route('/home')
def home():
    return render_template('home1.html')

@app.route('/layout')
def layout():
    return render_template('layout.html')

@app.route('/layout1')
def layout1():
    return render_template('layout1.html')


if __name__ == '__main__':
    app.run()
